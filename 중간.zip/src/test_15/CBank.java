package test_15;

public class CBank extends Bank {

	double InterestRate = 3.0;

	@Override
	public double getInterestRate() {
		return InterestRate;
	}
	
	
}
