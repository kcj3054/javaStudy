package test_15;

public class Bank {

	double InterestRate ;
	
	public double getInterestRate() {
		return InterestRate;
	}
}
