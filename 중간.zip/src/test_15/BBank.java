package test_15;

public class BBank extends Bank {

	double InterestRate = 5.0;

	@Override
	public double getInterestRate() {
		return InterestRate;
	}
	
	
}
