package test_17;

public abstract class Calc {

	int a, b;
	
	abstract void setValue(int a, int b);
	abstract int calculate();
}
