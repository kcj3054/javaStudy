package test_16;

public class Shape {

	private int x, y;

	public Shape() {
		System.out.println("Shape Constuctor");
	}

	public Shape(int x, int y) {
		this.x = x;
		this.y = y;
		
		System.out.println("Shape Constuctor");
	}
	
	
}
