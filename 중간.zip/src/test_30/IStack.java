package test_30;

public interface IStack<T> {

	T pop();
	boolean push(T ob);
}
