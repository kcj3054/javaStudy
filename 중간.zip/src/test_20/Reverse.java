package test_20;

import java.util.Scanner;

public class Reverse {

	void reverse() {
		Scanner sc = new Scanner(System.in);
		System.out.println("���ڸ� �Է��ϼ���");
		String input = sc.nextLine();
		
		int len = input.length();
		
		char[] change = new char[len];
		
	}
	public static void main(String[] args) {

		
	}

}
